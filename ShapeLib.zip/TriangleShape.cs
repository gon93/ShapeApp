﻿using System.Drawing;

namespace ShapeApp1.ShapeLib
{
    public class TriangleShape : Shape
    {
        public TriangleShape(Point position)
        {
            base.Position = position;
            base.BoundBox = new Rectangle(base.Position.X - 20, base.Position.Y - 20, 20, 20);
        }
        public override void Draw(Graphics g)
        {
            Pen pen = new Pen(Color.White);
            Point[] points = new Point[] {new Point(base.Position.X ,base.Position.Y - 10),new Point(base.Position.X - 10,base.Position.Y + 10),new Point(base.Position.X + 10,base.Position.Y + 10) };
            g.DrawPolygon(pen,points);
        }

        public override string ToString()
        {
            return string.Format("Type: {0}, Position: {1}", "Triangle",base.Position.ToString());
        }
    }
}