﻿using System.Drawing;

namespace ShapeApp1.ShapeLib
{
    public class RectangleShape : Shape
    {
        public RectangleShape(Point position)
        {
            Position = position;
            BoundBox = new Rectangle(base.Position.X - 20, base.Position.Y - 20,20,20);
        }
        public override void Draw(Graphics g)
        {
            Pen pen = new Pen(Color.White);
            g.DrawRectangle(pen, BoundBox);
        }

        public override string ToString()
        {
            return string.Format("Type: {0}, Position: {1}", "Rectangle", base.Position.ToString());

        }
    }
}