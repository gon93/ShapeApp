﻿using System.Collections.Generic;

namespace ShapeApp1.ShapeLib
{
    public delegate void EnableUnRedoHandler(UnRedoManager manager);

    public class UnRedoManager
    {
        private Stack<IShape> UndoStack;
        private Stack<IShape> RedoStack;

        public event EnableUnRedoHandler EnableUnRedoChanged;

        public UnRedoManager()
        {
            this.UndoStack = new Stack<IShape>();
            this.RedoStack = new Stack<IShape>();
        }

        public bool InsertUndoStack(IShape shape)
        {
            this.UndoStack.Push(shape);

            this.RedoStack.Clear();

            if (this.EnableUnRedoChanged != null)
                this.EnableUnRedoChanged.Invoke(this);

            return true;
        }

        public void Undo(IShape shape = null)
        {
            IShape unShape = null;
            if (shape != null)
            {
                while (true)
                {
                    unShape = this.UndoStack.Pop();
                    unShape.Undo();

                    this.RedoStack.Push(unShape);

                    if (unShape == shape)
                        break;
                }
            }
            else
            {
                unShape = this.UndoStack.Pop();
                unShape.Undo();

                this.RedoStack.Push(unShape);
            }

            if (this.EnableUnRedoChanged != null)
                this.EnableUnRedoChanged.Invoke(this);
        }



        public void Redo(IShape shape = null)
        {
            IShape reShape = null;
            if (shape != null)
            {
                while (true)
                {
                    reShape = this.RedoStack.Pop();
                    reShape.Redo();

                    this.UndoStack.Push(reShape);

                    if (reShape == shape)
                        break;
                }
            }
            else
            {
                reShape = this.RedoStack.Pop();
                reShape.Redo();

                this.UndoStack.Push(reShape);
            }

            if (this.EnableUnRedoChanged != null)
                this.EnableUnRedoChanged.Invoke(this);
        }

        public bool IsUndoPossible()
        {
            return this.UndoStack.Count > 0;
        }

        public bool IsRedoPossible()
        {
            return this.RedoStack.Count > 0;
        }
    }
}