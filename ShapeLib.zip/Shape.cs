﻿using System.Drawing;

namespace ShapeApp1.ShapeLib
{
    public abstract class Shape : IShape
    {
        public Point Position { get; set; }
        public bool IsVisible { get; set; }
        public Rectangle BoundBox { get; set; }

        protected Shape()
        {
            this.IsVisible = true;
        }
        public abstract void Draw(Graphics g);

        public new abstract string ToString();

        public bool HitTest(Point point)
        {
            if (!IsVisible)
            {
                return false;
            }

            var isInside = BoundBox.IntersectsWith(new Rectangle(point.X - 10, point.Y - 10, 2, 2));

            return isInside;
        }

        public void Undo()
        {
            throw new System.NotImplementedException();
        }

        public void Redo()
        {
            throw new System.NotImplementedException();
        }
    }
}