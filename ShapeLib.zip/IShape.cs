﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace ShapeApp1.ShapeLib
{
    public interface IShape
    {
        void Draw(Graphics g);
        void Undo();
        void Redo();
        string ToString();
        bool HitTest(Point point);

        Point Position { get; set; }
        bool IsVisible { get; set; }
        Rectangle BoundBox { get; set; }
    }
}
